var docObj = activeDocument;
var targetObj = [];
var result = [];

// ドキュメント内からテキストを取り出す
for(var i=0; i<docObj.pageItems.length; i++){
	typ = docObj.pageItems[i].typename;
	if (typ != "TextFrame") continue; // テキスト以外は無視
	targetObj.push(docObj.pageItems[i]); // 対象を格納
}

filename = File.openDialog("csvファイルを指定してください","*.csv");
var fileObj = new File(filename);
var obj = {};

var flag = fileObj.open ("r","","");
if (flag){
	var docRef = app.activeDocument;
	var tmp = fileObj.read();
	var str = tmp.split("\n");

	for (i=0; i<str.length;  i++){
		result = str[i].split(',');
		if (obj[result[0]] == undefined){
			obj[result[0]] = result[1];
		} else {
			obj[result[0]] = obj[result[0]] + result[1];
		}
		result = [];
	}

	for(var p=0; p<targetObj.length; p++){
		targetObj[p].contents = targetObj[p].contents.replace(targetObj[p].contents, obj[targetObj[p].contents]);
    }

}
